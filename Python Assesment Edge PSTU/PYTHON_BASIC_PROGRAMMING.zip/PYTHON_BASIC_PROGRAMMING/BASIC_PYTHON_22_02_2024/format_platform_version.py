import platform # Statement

version = platform.python_version()

print('This is a python version: {}' . format(version))
print(f'This is a python version {version}')