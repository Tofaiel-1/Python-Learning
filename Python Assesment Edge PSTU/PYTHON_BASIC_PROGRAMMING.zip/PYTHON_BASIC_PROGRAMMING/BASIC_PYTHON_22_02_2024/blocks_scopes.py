x , y = 24, 45
print(x)

food = ['Breakfast', 'Launch', 'Dinner']

for f in food:
    print(f)


n = 0
food = ['Breakfast', 'Launch', 'Dinner']
while n < range(food):
    print(n)
    n = n + 1