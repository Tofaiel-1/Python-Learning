def runMe(name):
    
    print(f'{name} is running.')

runMe('Maruf')



