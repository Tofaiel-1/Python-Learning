a = 75
b = 'Hellow World {}' . format(type(a))
print(b)