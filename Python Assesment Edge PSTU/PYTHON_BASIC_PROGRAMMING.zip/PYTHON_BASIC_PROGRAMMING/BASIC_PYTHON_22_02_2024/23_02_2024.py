#Data Types in python( List, Tuple, Dictionary, Set)

#Loops in python Functions, Objects. 3 hours Lecture and lab
#String type in detail, Numeric types, Boolean types, Sequence types.

#Type Id instance, Conditions (If else, elif). 3 hours Lecture and lab
#Ternary operators, arithmetic operators. 3 hours Lecture and lab
#Comparison Operators, Boolean operators. 3 hours Lecture and lab
#While loop, For Loop, Loop Control.

#Expressions ans statements
# x = y // Assignment
# x * y // Operation
# (x,y) //Aggregation (Tuple)
# x // Simple Value
# True //Contant Value
#f() //Function Calling

