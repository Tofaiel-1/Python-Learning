#name = input('Enter your name here: ')

#n = name.lower()

#print(name.lower())


c = 'Python For Beginers.'

print(c.replace('Beginers' , 'Advance'))




#Pascle_case

#Full_name

#fullName = 

#class Python:

#camelCase


