class Hours:

    def morning(self):
        print('In morning i feel fresh!')
    
    def evening(self):
        print('In evening i feel tired!')


how_i_feel = Hours()

how_i_feel.evening()

