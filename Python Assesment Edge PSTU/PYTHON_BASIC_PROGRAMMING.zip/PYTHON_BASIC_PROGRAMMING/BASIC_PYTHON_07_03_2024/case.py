name = 'eqram'

print(name.capitalize())


course = 'Basic Python Class.'
#print(course)
print(course.replace('Basic Python Class.' , 'Digital Marketing Class.'))