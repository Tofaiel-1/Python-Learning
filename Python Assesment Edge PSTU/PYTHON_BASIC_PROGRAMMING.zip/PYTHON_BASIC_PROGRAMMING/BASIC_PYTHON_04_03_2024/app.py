



class Hours:
    def morning(self):
        print("I feel fresh!")
    def evening(self):
        print('I feel tired!')
how_i_feel = Hours()
how_i_feel.morning()
how_i_feel.evening()

