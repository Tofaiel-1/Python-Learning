#batch_b = {'Students No' : 12 , 'Subject': 'Python'}


#del batch_b['Students No']

#print(batch_b)


#students = [0, 1, 2, 3, 4, 5, 6]

#students.pop(4)

#print(students)


s_info = {'Name' : 'Mohibullah', 'Semester': '3rd', 'Hall Name' : 'Bangabandhu Hall.'}


s_info.update({'Faculty' : 'CSE'})

print(s_info)


