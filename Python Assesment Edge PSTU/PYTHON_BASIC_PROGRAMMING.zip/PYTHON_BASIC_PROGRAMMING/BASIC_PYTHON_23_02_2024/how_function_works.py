
is_rainy_day = True

if is_rainy_day:
    print('I will buy an umbrella!')
else:
    print('I Will buy a bottle of Cold Water!')



