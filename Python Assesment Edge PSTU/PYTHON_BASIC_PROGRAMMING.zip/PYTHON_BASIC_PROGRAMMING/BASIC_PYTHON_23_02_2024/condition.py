a, b , c , d = 1.1 , 2.5 , 3.6 , 4.7

if a < b:
    print(f'A is lesser than B. Where A is {a} and B is {b}.')
elif b > c:
    print(f'B is lesser than C. Where B is {b} and C is {c}.')
elif c > d:
    print(f'C is lesser than D. Where C is {c} and D is {d}.')
else:
    print("Condotion Doesn't Mached. Sorry!")

