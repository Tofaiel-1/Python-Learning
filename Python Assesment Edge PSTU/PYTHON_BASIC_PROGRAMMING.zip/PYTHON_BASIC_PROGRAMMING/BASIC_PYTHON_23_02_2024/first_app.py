a =  22
b = 23

# 22 < 23:
if a < b:
    print('A is Greater than B')
else:
    print('B is Greater Than A')




