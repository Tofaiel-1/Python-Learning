def runMe(name):
    print("Hello " + name + "!" + " Run please!")
    print(f"{name} is running!")

runMe("Abeer")


n = 0



def value(m = 30):
    print(m)
    return m - 15

value()
v = value()
print(v)


