# Importing a module
import math

# Using functions from the math module
print(math.sqrt(16))

# Importing specific functions from a module
from random import randint

# Using the randint function directly
print(randint(1, 10))
