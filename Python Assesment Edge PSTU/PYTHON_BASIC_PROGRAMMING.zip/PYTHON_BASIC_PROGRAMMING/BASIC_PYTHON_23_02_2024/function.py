


def counting_length():
   
   py = "We are learning Python."

   if len(py) > 23:
      print('Ok')
   else:
      print('Not Ok!')
      
counting_length()

#find
#replace('Beginners', 'Absolute Beginners')
# in operator , boolean expression
#title()
#x +=3
#operator_precedence
#10 + 3 * 2
#expon 2**3 power
#overrides
#x = (2 + 3) * 10 -3
#round(2.9)
#abs()


#good credit = 0.1 * price
#is not = 0.2 * price


#AND : both
#OR : at_least



#good_record criminal


#If name > 30 or < 50

    
     




        





