name = input('Give your name here.. ')

message = '''

            Happy Eid Day 
            
            {}.
            
            Thank You! 
            
            ''' .format(name)

print(message)

