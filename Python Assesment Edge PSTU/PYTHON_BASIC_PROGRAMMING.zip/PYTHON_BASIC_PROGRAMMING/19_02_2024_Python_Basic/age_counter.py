birth_year = input('What is your birth year? ')

age = 2024 - int(birth_year)

print("You are " + str(age) + " Years Old.")

