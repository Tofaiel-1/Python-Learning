### Loops in python Functions, Objects.
### String type in detail, Numeric types, Boolean.
### types, Sequence types.
### Lecture and lab.
### Type Id instance, Conditions (If else, elif).


print('o----')
print(' ||||')

print(" * " * 10 )


print(10)

print(type(10))



