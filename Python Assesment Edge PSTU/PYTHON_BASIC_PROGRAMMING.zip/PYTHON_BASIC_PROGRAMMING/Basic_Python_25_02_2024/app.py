#Single Line Comment

""" This is Multiline Comment
    This is Multiline Comment
    This is Multiline Comment
    This is Multiline Comment
    This is Multiline Comment
    This is Multiline Comment
    This is Multiline Comment
    This is Multiline Comment
    This is Multiline Comment """

#Below i will declare a variable in string type
s = 'STRING'

#Float 
f = 4.5

#Integer Type 
i = 5

#Boolean 
b = False


f = 4.5

name = 'Nahid'

print(   "This is the format of {}." .format(name))

print(   f"My name is  {name}.")












