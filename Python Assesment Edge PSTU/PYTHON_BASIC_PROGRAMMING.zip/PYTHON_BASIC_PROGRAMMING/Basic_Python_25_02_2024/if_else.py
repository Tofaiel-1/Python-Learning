n = 5
m = 5

if n == m:
    print('N is equal to M.')
elif n > m:
    print('N is greater than M')
elif n < m:
    print('N is greater than M')
else:
    print('Something else')


