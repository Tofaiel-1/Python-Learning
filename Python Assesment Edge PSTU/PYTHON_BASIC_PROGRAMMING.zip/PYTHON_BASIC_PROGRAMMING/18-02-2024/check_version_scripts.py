import platform

version = platform.python_version()

print("This is python version {}" . format(version))