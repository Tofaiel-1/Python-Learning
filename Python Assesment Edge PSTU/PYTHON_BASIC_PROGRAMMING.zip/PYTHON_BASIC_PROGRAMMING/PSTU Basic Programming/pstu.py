#Variable Declariation
a = 50
b = 10

c = a - b

print(c)

