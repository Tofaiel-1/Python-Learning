name = input(' Insert Your Name, to See A Greeting Message: ')




age = input('Insert Your Age Here: ')



print( f'Your name is: {name}. You are {age} Years Old!' )









