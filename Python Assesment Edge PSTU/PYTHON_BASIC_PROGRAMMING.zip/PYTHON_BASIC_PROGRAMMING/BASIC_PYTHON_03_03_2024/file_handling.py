

with open("file.txt", "r") as f:
    x = f.read()
    print(x)





#   Nested Loops #
    
#numbers = (1 , 2 , 3  , 4 , 5 , 6 , 7 , 8 , 9 , 10)

#for i in numbers:
    #for j in numbers:
        #print(i , j)
    

multiply = lambda x, y: x * y

print(multiply(4,5))



    






    

