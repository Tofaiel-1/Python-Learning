
import platform

v = platform.python_version()

print(v)


# def is a Reserved keyword in python
def carryMe(v):

    print(f'I am carrying the value of parameter as argument: {v}')

carryMe(0)







