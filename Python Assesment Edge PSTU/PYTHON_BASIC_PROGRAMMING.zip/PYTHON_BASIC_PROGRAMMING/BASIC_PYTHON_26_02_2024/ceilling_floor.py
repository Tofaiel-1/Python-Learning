import math

v = 169.49

w = math.floor(v)

print(w)


