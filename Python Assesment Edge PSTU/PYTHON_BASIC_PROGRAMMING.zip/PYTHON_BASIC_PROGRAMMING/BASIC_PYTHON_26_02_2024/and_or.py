has_good_credit = True

has_criminal_record = False

if has_good_credit == True and has_criminal_record == False:
    print("Able to Pay 100 taka.")
else:
    print("He will Pay 1000 taka.")


py = "Python for Basic"