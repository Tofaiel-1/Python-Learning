f = open("myfile.html" , "x")

f.write('Append is a py function!')