from person import Person


person = Person()
person.introduce()
#person1 = Person('Abeer Bin Bashar Sadi' , 30 , 'Mohammadpur, Dhaka-1207.')

#person1.introduce()
