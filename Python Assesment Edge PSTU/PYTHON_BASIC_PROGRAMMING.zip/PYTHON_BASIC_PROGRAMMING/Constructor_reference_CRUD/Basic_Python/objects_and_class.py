class Hours:
    def morning(self):
        print('I feel Fresh!')
    def evening(self):
        print('I feel Tired!')


how_i_feel = Hours()

how_i_feel.morning()
how_i_feel.evening()

