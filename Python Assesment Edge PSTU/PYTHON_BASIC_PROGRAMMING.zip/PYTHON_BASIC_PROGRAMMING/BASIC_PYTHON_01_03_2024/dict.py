students = ['Alim', 'Bukhary', 'Joy']

data = {'name' : 'Alim', 'Id': 2000432, 'Batch' : 140034, 'Semester' : '5th'}


data['Grade'] = 'A+'

del data['Semester']

print(data)

