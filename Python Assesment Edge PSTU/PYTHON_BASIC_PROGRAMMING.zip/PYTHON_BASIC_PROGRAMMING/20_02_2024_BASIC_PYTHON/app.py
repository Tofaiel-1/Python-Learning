#Integer Whole Number:
#Parenthesis

#int()

#age = 22

#print(type(age))

#print("Your are " + str(age) + " years old.")

cgpa = 3

cgpa = float(cgpa)

print(cgpa)
print(type(cgpa))




