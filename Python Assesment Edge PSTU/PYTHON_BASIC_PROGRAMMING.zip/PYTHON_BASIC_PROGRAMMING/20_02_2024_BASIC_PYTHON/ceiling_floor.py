from math import floor

rating = 4.9

rating = floor(rating)

print(rating)