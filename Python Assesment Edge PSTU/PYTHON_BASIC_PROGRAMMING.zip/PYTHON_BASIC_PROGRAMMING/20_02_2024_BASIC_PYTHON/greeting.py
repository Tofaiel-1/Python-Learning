name = input('Give Your Name Here: ')

greeting = f"Thank You {name}."

print(greeting)