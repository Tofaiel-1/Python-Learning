#t = type(age)

#print(t)


#Float Decimal Point Number:
float()
cgpa = 3.5

#String Data: 

''' 

str()
name = "Nihal"

'''
#Boolean
bool()
is_gloomy = True
today_was_sunny_day = False
