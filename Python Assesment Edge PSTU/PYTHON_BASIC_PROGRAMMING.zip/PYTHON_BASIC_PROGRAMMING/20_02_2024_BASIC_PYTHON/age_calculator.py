birth_year = input(' Give me your Birth Year to Calculate your Age: ')

age = 2024 - int(birth_year)

print(age)


