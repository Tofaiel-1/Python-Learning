import turtle as tur
import colorsys as cs
tur.setup(800,800)
