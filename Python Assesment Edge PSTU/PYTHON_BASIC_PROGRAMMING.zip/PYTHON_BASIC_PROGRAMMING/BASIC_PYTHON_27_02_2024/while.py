i = 0  # Define i as an integer variable, starting from 0

while i <= 9:  # Iterate until i is less than or equal to 9
    print(i)
    i += 1  # Increment i by 1 in each iteration

