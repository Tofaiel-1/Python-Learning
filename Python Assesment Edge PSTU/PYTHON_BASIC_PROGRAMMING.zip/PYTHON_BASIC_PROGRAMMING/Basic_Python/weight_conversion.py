weight_in_pounds = input('Give your Weight in pounds: ')
weight_in_kilograms = int(weight_in_pounds) * 0.45
print(weight_in_kilograms)