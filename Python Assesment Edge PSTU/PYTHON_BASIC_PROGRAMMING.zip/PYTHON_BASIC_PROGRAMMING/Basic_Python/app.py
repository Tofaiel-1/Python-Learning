print("Hello World")
print("o----")
print(" ||||")
print("*" *  10)


#Variables

price = 10
price = 20
print(price)
print(type(price))
name = "PSTU"
print(name)
print(type(name))
rating = 5.00
print(rating)
print(type(rating))
is_open = True
print(is_open)
print(type(is_open))

