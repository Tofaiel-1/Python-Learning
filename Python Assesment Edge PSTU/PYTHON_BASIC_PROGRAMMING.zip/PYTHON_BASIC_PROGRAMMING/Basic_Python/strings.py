course = "Python's course for Beginners"
course = 'Python for "Beginners" '
print(course)