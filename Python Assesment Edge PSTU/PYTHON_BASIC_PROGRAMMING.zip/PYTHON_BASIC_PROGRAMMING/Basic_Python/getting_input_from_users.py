full_name = input('What is your name? ')
favourite_color = input('What is your favourite color? ')
print( full_name + ' likes ' + favourite_color)

birth_year = input('What is your birth year? ')

age = 2024 - int(birth_year)
print( full_name + ' is ' + str(age) + ' years old ' + 'and likes the color ' + favourite_color + '.')