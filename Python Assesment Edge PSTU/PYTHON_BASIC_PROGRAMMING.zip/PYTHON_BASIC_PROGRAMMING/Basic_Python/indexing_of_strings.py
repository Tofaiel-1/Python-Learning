course = "Python Programming"
index = course.find("Python")
index = course[:3]
print(index)