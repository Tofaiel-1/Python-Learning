





a = 1
b = 2

if a < b:
    print(f'{a} is Greater than: {b}.')

elif a != b:

    print(f'{a} is not equal to: {b}')

else:
    print("""
          Block changed!
          Because condition doesn't matched.
          """)
    
print('We are reviewing If, elif and else statements!')

