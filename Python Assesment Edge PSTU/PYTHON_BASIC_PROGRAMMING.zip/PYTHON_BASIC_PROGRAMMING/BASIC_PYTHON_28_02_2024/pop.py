students = [1, 2, 3, 4, 5, 6, 7, 8, 9]

print(students[0:3])

#students.pop(6)



