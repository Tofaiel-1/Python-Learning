def greet():

    name = input('Give Your Name Here: ')

    age = input('Give your age Here: ')

    favourite_color = input('Give your Favourite Color: ')

    print(f"""
          
          Hi {name}!
          
          You are {age} years old.

          And your favourite color is {favourite_color}.

          Thank You!  
          
          """)
greet()



















