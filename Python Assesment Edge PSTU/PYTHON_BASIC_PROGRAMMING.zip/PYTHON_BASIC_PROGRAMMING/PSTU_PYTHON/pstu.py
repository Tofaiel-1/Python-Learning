import platform

version = platform.python_version()

###########        Were printing something below        ################

print("This is python version: {} " . format(version))


