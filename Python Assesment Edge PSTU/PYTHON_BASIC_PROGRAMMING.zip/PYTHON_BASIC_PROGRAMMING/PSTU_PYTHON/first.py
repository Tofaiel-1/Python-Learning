print("We are learning python!")

